<?php
class TransactionsRangeFilterVO {
	
	/**
	 * Array of DB field names to load. Use 'null' for '*' (to get all fields)
	 */
	public $fields;
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Timestamp (in unix format) will be returned only transactions with timwstamp bigger than this.
	 */
	public $dateFrom;
	
	/**
	 * Will be returnred transactions with unixtimestamp  less or equal than this given timestamp.
	 */
	public $dateTo;
	
	/**
	 * There are two date field in transaction records: 'created' and 'changed'.
	 * So dataFrom and dateTo are applyed to one of those - you can chose to which one.
	 */
	public $dateFieldName = 'changed';
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * UIDs of users to search for transactions.
	 */
	public $usr = array('changed');
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Load only transactions of the given types.
	 */
	public $type = array('changed');
	
	/**
	 * Status indicator of the transactions.
	 */
	public $status = array('changed');
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Array of places delta IDs (DID)
	 */
	public $place = array('changed');
	
	/**
	 * Array of node ID's (product IDs) to filter. So only transactions with these products will be shown.
	 */
	public $nids = array('changed');
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Fields to order in. The ones from DB fields: 'created', 'changed', 'value', 'place', 'usr_they', 'usr_us'
	 */
	public $order = array('changed');
	
	/**
	 * Number of transactions to get.
	 */
	public $limit = 100;
	
	/**
	 * Max number of DB transaction records to search in while the 'limit' is not reached.
	 * Used when server needs to load transaction fully to make right filtering (rarely used).
	 */
	public $maxSearch = 1500;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public function __construct($data=null) {
		if(is_object($data)) $data = (array)$data;
		if(!is_array($data)) return;
		
		foreach ($this as $field => $value) {
			if(isset($data[$field])) $this->{$field} = $data[$field];
		}
	}
	
}

?>