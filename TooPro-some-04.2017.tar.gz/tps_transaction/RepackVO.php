<?php
class RepackVO {
	/**
	 * Nid of source node product, from which available amount will be decreased
	 * @var uint node id of the source product, which will be repacked
	 */
	public $source;
	
	/**
	 *Nid of the node where available amount will be added
	 * @var uint node id of the destination product
	 */
	public $destination;
	
	/**
	 * @var float Multiplier used like destination=source*rate, can be less than 1
	 */
	public $rate;
	
	/**
	 * @var boolean if true - this repack can be reverced, so some amounts of destination products can be converted to source product back
	 */
	public $reverce = FALSE;
	
	/**
	 * @var String any text admin need to say to seller, who is doing this repack
	 */
	public $note;
}