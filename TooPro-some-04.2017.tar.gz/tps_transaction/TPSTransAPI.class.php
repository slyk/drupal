<?php

/**
 * Used to store transaction processing functions.
 * 
 * @author SlyK
 *
 */
class TPSTransAPI {
	

	/**
	 * Add transaction to DB
	 * @param TPSTrans $transaction data array(
	 * 		'id'	  =>String (to update),//symbolic if id is set the transaction with given id will be updated
	 * 		'usr_they'=>int, 			//buyer userID for which transaction is created)
	 * 		'usr_us'  =>int(optional),	//seller userID who initiated transaction. if not set - current logged in user id is used
	 * 		'type'	  =>int(required),	//type of the transaction, system can predict many types (using value and debt fields) but you better set this.
	 * 		'value'   =>float(optional),//ammount of money will be +/- of the balance of place given in 'place' var. If not set - use 0, if value<0 it's income(приходная) transaction(T_INCOME). money decreased from sell place balance and availability of products increased (products taken from data property)
	 * 		'place'	  =>int,			//id of the place on which operation is performed
	 * 		'data'	  =>array(			//data for transaction, saved as serialized array to DB field.
	 * 			'debt'=>float(optioanl),//..amount of money buyer was credited. this amount will go to buyers debt field. default - 0. It debt<0 - meend user returned money(T_DEBTBACK) so sell place balance will be increased for this amount and curr user debt will be decreased for this value
	 * 			'products'=>array(),	//array of products in transactions with amounts of them that was used
	 * 			'saleUsed'=>array(),	//node object of the currenty used sale (for sell transactions)
	 * 		),
	 * 		'status'  =>int,			//current statusID of the transaction. 0 is 'done' - others numbers see in documentation
	 * 		'note'	  =>String(optional)//any note user can add here
	 * 		There is no 'debt' filed in transaction db structure, so 'debt' must be added to buyers debt in script.
	 * @param $deepCheck set to FALSE if you are fully  shure amout data given in transaction, because it will not be cheked and sanityzed when this settd to FALSE. But this helps to save some mysql requests.
	 * @return TPSTrans|string Transaction object with POPULATED ID param, or String on error(containing error description).
	 */
	public static function add(&$transaction, $deepCheck = TRUE) {
		unset($transaction->id);												//for validator to understood that this will be new transaction unset any id
		
		//make all validations
		$validRes = TPSTransValidator::validate($transaction, $deepCheck);
		if(is_string($validRes)) return $validRes;
		
		//calculate updates of the all connected data (products, users, sell places, etc...)
		$upd = TPSTransAPI::_calculate_delta_updates($transaction);				//calculate delta updates
		if(is_string($upd)) return $upd;										//if there was some error in updatings - return them
		$DBtrans = db_transaction();
		$upd = tps_core_apply_delta_updates($upd);								//apply received updates to the system - $upd will get FINAL updated values
		
		//write transaction to db:
		$res = $transaction->write_db_record_only(TPSTrans::WRITE_NEW_NEXT);
		if($res) {
			$DBtrans->rollback();
			return $res;
		}
		
		//trans saved, finalize operation with some additional processing:
		module_invoke_all('tps_transaction', 'add', $transaction);				//call all hooks for transacton insert
		$_SESSION['tps_transaction_updates'] = $upd;							//store final values of the updated variables to session vars, will send them to client later (used by Retail Services resource fuinctions)
		
		//return transaction with symbolic ID populated
		$transaction->id = TPSTransAPI::IDintTOstr($transaction->id);			//convert int id to symbolic before returning to user	
		return $transaction;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Loads the range of transactions array using given filter.
	 * See TransactionsRangeFilterVO class about filtering ability.
	 * @param TransactionsRangeFilterVO $filterObj
	 * @return array of transactions or STRING with error text.
	 */
	public static function range($filterObj=null) {
		//populate filter obj with defaults
		$defFilter = (object)array(
				'dateFieldName' => 'changed',
				'order'			=> array('changed'),
				'limit'			=> 100,
				'maxSearch'		=> 600
		);
		if($filterObj) {
			if(is_array($filterObj)) $filterObj = (object)$filterObj;
			foreach($defFilter as $key=>$val) if(!isset($filterObj->{$key})) $filterObj->{$key} = $val;
		}else $filterObj = $defFilter;
		
		//------------------------------------------------
		//PREPEARE QUERY:
		
		//..general select:
		if(count($filterObj->fields)) $sqlflds = implode(',', db_escape_field($filterObj->fields));	else $sqlflds = '*';
		$q = "SELECT $sqlflds FROM {tps_transaction}";
		
		//..where conditions:
		$where = array();
		if($filterObj->dateFrom	) $where['dateFrom']	= " `{$filterObj->dateFieldName}` >={$filterObj->dateFrom} ";
		if($filterObj->dateTo	) $where['dateTo']		= " `{$filterObj->dateFieldName}` <={$filterObj->dateTo} ";
		
		if(count($filterObj->usr  )) $where['usr']= ' ( `usr_us` IN(' . implode(',',self::onlyIntArray($filterObj->usr)) . ') OR `usr_they` IN(' . implode(',',self::onlyIntArray($filterObj->usr)) . ') )';
		
		if(count($filterObj->type  )) $where['type'  ]	= ' `type`   IN(' . implode(',', self::onlyIntArray($filterObj->type  )) . ') ';
		if(count($filterObj->status)) $where['status']	= ' `status` IN(' . implode(',', self::onlyIntArray($filterObj->status)) . ') ';
		
		if(count($filterObj->place)) $where['place']	= ' `place` IN(' . implode(',', self::onlyIntArray($filterObj->place)) . ') ';
		if(count($filterObj->nids)) {
			$nidsWhere = array();
			foreach ($filterObj->nids as $nid) {
				$nid = intval($nid);
				$nidsWhere[$nid] = " `data` LIKE '%s:3:\"nid\";i:$nid;%' ";
				$nidsWhere[$nid].= " OR `data` LIKE '%s:3:\"nid\";s:" .strlen($nid). ':"'.$nid.'";s:%\' ';//for inventory another saving format- nid as string
			}
			$nidsWhere = ' (' . implode(' OR ', $nidsWhere) . ') ';
			$where['nids'] = $nidsWhere;
		}
		
		//..order and limit
		$order = ' ORDER BY ' . implode(', ', db_escape_field($filterObj->order)) . ' DESC ';
		$limit = ' LIMIT '.intval($filterObj->limit);
		
		//..finally get all additional statements to the query string
		if(count($where)) $q = $q . ' WHERE (' . implode(' AND ', $where) . ') ';
		$q = $q . $order . $limit;
		
		//------------------------------------------------
		//MAKE QUERY:
		//watchdog('range', 'query = '.$q);
		$res = db_query($q);
			
		//parse data to array
		$ret = array();
		while($row = $res->fetchObject()) if($row) $ret[] = $row;		//not doing processing now, just save to array
		foreach ($ret as &$row) {
			$row->id=TPSTransAPI::IDintTOstr($row->id);			//change id to symbolic
			if(is_string(@$row->data)) $row->data = unserialize($row->data);	//unserialize data hash. because we receiving records directly from Db, noy using read_record it's not unserialized automatically
			
			//special processing of inventory records
			if(null!=@$row->data->products && null!=@$row->data->products[0]->availReal) {
				$prodArr = $row->data->products;
				foreach ($prodArr as &$product) {
					$product->amount = $product->availReal;
					$product->title  = "Difference is ".$product->availDiff;
					if(in_array($product->nid, $filterObj->nids))
						$row->note = "разница ".$product->availDiff." (при переучете), посчитано: ".$product->availReal;
				}
			}
			//special processing of NID request, for more info in note
			if(null!=@$row->data->products && $row->type!=TPSTrans::T_INVENROTY) {
				$prodArr = $row->data->products;
				foreach ($prodArr as &$product) if(in_array($product->nid, $filterObj->nids)) {
					//$wasPrefix = "(было ".$product->avail[6].") ";
					//$product->title  = $wasPrefix . $product->title;
					if($row->type==TPSTrans::T_INCOME) $multip = -1; else $multip = 1;
					//$row->note = "стало ".($product->avail[6]-$product->amount*$multip).' '.$wasPrefix . $row->note;
					$row->note = $row->note . " измен ".date("d.m.y H:i", $row->changed) . " указ ".date("d.m.y H:i", $row->created); 
					if($row->type!=TPSTrans::T_SELL) $row->note = "! ".$row->note;
				}
			}

		}
		return $ret;
		
	}//range_adv()
	
	
	public static function onlyIntArray($arr) {
		foreach($arr as &$val) {
			if(is_numeric($val)) $val = intval($val);
		}
		return $arr;
	}
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	/**
	 * Delete transaction from DB and REVERT it's changes (available values are back, money values returned, etc.).
	 * @param String $transId id of the transaction to delete
	 * @param boolean $symbolic if true, then $transId contains symbolic representatrion of the transaction id
	 * 		  and must be converted to id before db query. Defaults to true, because internal integer id of the transaction
	 * 		  almost always don't goes out, because it's converted to symbolic after retriving transaction from db.
	 * @return String with error message or UpdatesVO object with updates that was made after deletion
	 */
	public static function delete($transId, $symbolic=TRUE) {
		//load full transaction data and check do we can delete it:
		if(is_object($transId)) $transId = $transId->id;				//if already transaction object is given - use its ID, but load it from DB (for security purposes)
		$trans = TPSTransAPI::read($transId, $symbolic);				//get full transaction info
		$trans = TPSTransValidator::castHashes($trans);					//cast loaded data hash to transaction
	
		//CHECK / validate
		$validRes = TPSTransValidator::validate($trans, FALSE, TRUE);	//validate trans for deletion
		if(is_string($validRes)) return $validRes;						//if some error - return message
	
		//calculate and save apply data changes after transaction deletion
		$upd = TPSTransAPI::_calculate_delta_updates($trans, TRUE);		//calculate delta updates
		if(is_string($upd)) return $errorMsg = $upd;					//if there was some error in updatings - save them
		$DBtrans = db_transaction();
		$upd = tps_core_apply_delta_updates($upd);						//apply received updates to the system - $upd will get FINAL updated values
		
		//change status of the transaction and write it to DB
		$trans->status = TPSTrans::S_DELETED;							//change status
		$trans->changed= time();										//save changed time, for sync to know it need to clear this transa again on clients
		
		//update transaction in db:
		$res = $trans->write_db_record_only(TPSTrans::WRITE_UPDATE);
		if($res) {
			$DBtrans->rollback();
			return $res;
		}
				
		//return final updated values after deletion was made
		module_invoke_all('transaction_write', 'delete', $trans);		//call all hooks for transacton insert
		$upd->transactions[$trans->id] = (object)array('status' => TPSTrans::S_DELETED);	//put transaction status to UpdatesVO
		return $upd;
	}
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Read all data about one transaction.
	 * @param $transId ID of needed transaction. Can pe String (if $symbolic is true) and intetger (when $symbolic is false)
	 * @param boolean $symbolic if true, then $transId contains symbolic representatrion of the transaction id
	 * 		  and must be converted to id before db query. Defaults to true, because internal integer id of the transaction
	 * 		  almost always don't goes out, because it's converted to symbolic after retriving transaction from db.
	 * @return OBJECT(stdClass) of all parameters of transaction
	 */
	public static function read($transId, $symbolic=TRUE, $fieldsArr = array()) {
		if($symbolic) $transId = TPSTransAPI::IDstrTOint($transId);
		$trans = db_select('tps_transaction');
		if(count($fieldsArr)) $trans->fields('tps_transaction', $fieldsArr); else $trans->fields('tps_transaction');
		$trans = $trans->condition('id', $transId)->execute()->fetchObject();
		
		if(!$trans) return null;
		if(isset($trans->id	 )) $trans->id	= TPSTransAPI::IDintTOstr($trans->id);
		if(isset($trans->data)) $trans->data= unserialize($trans->data);
		return (object)$trans;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Updte transaction. Mostly used on 'sell','transfer','income' transactions, when it happends not in one time.
	 * the most updated are - statuses. But on some statuses of transaction there is ability to change paiment value and products list.
	 * Final UpdatesVO will be returned
	 * @param string $transId ID of needed transaction. Can pe String (if $symbolic is true) and intetger (when $symbolic is false)
	 * @param object $edit hash of the chaghes
	 * @param boolean $symbolic if true, then $transId contains symbolic representatrion of the transaction id
	 * 		  and must be converted to id before db query. Defaults to true, because internal integer id of the transaction
	 * 		  almost always don't goes out, because it's converted to symbolic after retriving transaction from db.
	 * @return UpdatesVO|string final updates hash values or error string
	 */
	public static function update($transId, $edit, $symbolic=TRUE) {
		
		//load full transaction data:
		if(is_object($transId)) $transId = $transId->id;					//if already transaction object is given - use its ID, but load it from DB (for security purposes)
		$trans = TPSTransAPI::read($transId, $symbolic);					//get full transaction info
		$trans = TPSTransValidator::castHashes($trans);						//cast loaded data hash to transaction
		
		//for status updates
		if(isset($edit->status)) {
			$upd = self::updateStatus($trans, $edit->status, $symbolic);
			if(is_string($upd)) return $upd;
		}
		
		//save updates and store updated transaction to DB
		$DBtrans = db_transaction();
		$upd = tps_core_apply_delta_updates($upd);							//apply received updates to the system - $upd will get FINAL updated values
		$trans->changed= time();											//save changed time, for sync to know it need to clear this transa again on clients
		$res = $trans->write_db_record_only(TPSTrans::WRITE_UPDATE);
		if($res) {$DBtrans->rollback();	return $res;}
		
		//trans saved, finalize operation with some additional processing:
		module_invoke_all('transaction_write', 'update', $trans);			//call all hooks for transacton insert
		$_SESSION['tps_transaction_updates'] = $upd;						//store final values of the updated variables to session vars, will send them to client later (used by Retail Services resource fuinctions)
		return $upd;
	}
	
	/**
	 * Used to update transaction status. Mostly used on 'sell','transfer','income' transactions, when it happends not in one time.
	 * Statuses can be updated only in one direction, so that id of the status increased. Example: if you set 'sent' status, it meens it was payed.
	 * If all ok - saves UpdatesVO to $_SESSION['tps_transaction_updates'], for clients to update their data.
	 * @param TPSTrans $trans ID of needed transaction. Can pe String (if $symbolic is true) and intetger (when $symbolic is false)
	 * @param int $newStatus
	 * @param boolean $symbolic if true, then $transId contains symbolic representatrion of the transaction id
	 * @return string|UpdatesVO with error if there is some, or UpdatesVO
	 */
	private static function updateStatus(&$trans, $newStatus, $symbolic=TRUE) {
		
		//get old status and check it
		$oldStatus = $trans->status;
		if($oldStatus >= $newStatus) return "Старый статус транзакции($oldStatus) уже перекрыват новый($newStatus). Установка указанного статуса невозможна.";//check do we can set new status depend on old status
		
		//save status change info
		if(!isset($trans->data->status)) {									//if there was no status history array
			$trans->data->status = array();									//prepeare empty array
			$trans->data->status[$trans->changed] = $trans->status;			//save hostory info about old status timestamp
		}
		$trans->data->status['old'] = $oldStatus;							//save current 'old' status
		$trans->data->status[time()]= $newStatus;							//save histroy info about new status timestamp
		$trans->status = $newStatus;										//change status
		
		//calculate and save apply data changes after transaction status change
		$upd = TPSTransAPI::_calculate_delta_updates($trans);				//calculate delta updates
		if(is_string($upd)) return $errorMsg = $upd;						//if there was some error in updatings - save them
		$upd->transactions[$trans->id]=(object)array('status'=>$newStatus);	//put transaction status to UpdatesVO
		return $upd;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Get 'sum' value of the range of transactions in the given period of time. May use filters.
	 * Use it if you need to get cash by the user in some dates range rather than getting the range of transactions
	 * and summing in php. Or to get cash in the whole sell place for the past month.
	 * 
	 * Function uses mysql SUM() so it's faster that getting the big list of transactions.
	 * 
	 * @param int $start starting time for the transaction range to sum values
	 * @param int $end finish time
	 * @param array $arrFilter assoc array with filter values (allowed values: usr_they, usr_us, place, type, status) 
	 * @return int|string value of all transactions (may be negative) or error string.
	 */
	public static function getValueByDate($start, $end, $arrFilter = null) {
		//check dates
		$start	= intval($start);	$end	= intval($end);
		if(!$start || !$end) return 'Даты указаны неверно.';
		if(!is_array($arrFilter)) $arrFilter = (array)$arrFilter;
		
		//build request
		$req = db_select('tps_transaction','t');
		$req->addExpression('SUM(value)','val');
		$req->condition('created',$start, '>=');
		$req->condition('created',$end  , '<=');
		$req->condition('status', TPSTrans::S_PAYED, '>=');
		
		//add filters
		foreach($arrFilter as $field=>$val) {
			if($field=='usr_us'||$field=='usr_they'||$field=='type'||$field=='status'||$field=='place')//for these fields
				$req->condition($field, intval($val));													//we convert $val to int (for security)
		}
		
		//run and return value
		return 0+floatval($req->execute()->fetchField());
	}
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Decode shortened text back to integer id
	 * @param string $code
	 * @return FALSE if thre is some error
	 */
	public static function IDstrTOint($stringID) {
		$base		= strlen(TPSTrans::TID_CONV_SYBM);
	
		$rindex = array_flip(array_slice(preg_split("''",TPSTrans::TID_CONV_SYBM),1,-1));
		$len = strlen($stringID);
		$out = $rindex[$stringID[$len-1]];
		$k = 1;
		for($j = $len-2;$j >= 0;$j--) {
			if(!isset($rindex[$stringID[$j]])) return FALSE;
			$out = bcadd($out,bcmul($rindex[$stringID[$j]],bcpow($base,$k)),0);
			$k++;
		}
		return $out;
	}
	
	
	/**
	 * Set number of transaction as: 123(number of transaction today) + 02(month) + 1(sell place) + 25(day fo month)
	 * @param string $intId send this param here AS STRING, it will be converted automatically here (ошибка, если отправлять 0032, то придет не целое число 32, а что-то левое, поэтому надо брать в кавычки '0032')
	 */
	public static function IDintTOstr($intID) {
		$base		= strlen(TPSTrans::TID_CONV_SYBM);
		$ret = '';
	
		for($t = floor(log10($intID) / log10($base)); $t >= 0; $t--) {
			$a = floor($intID / pow($base,$t));
			$ret = $ret.substr(TPSTrans::TID_CONV_SYBM,$a,1);
			$intID = $intID - ($a*pow($base,$t));
		}
		return $ret;
	}
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	/**
	 * Get instance of this class
	 */
	static function i(){
		if (self::$instance == NULL){self::$instance = new TPSTransAPI();}
		return self::$instance;
	}
	static private $instance = NULL;
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Prepeare updates of given transaction, but NOT save them to DB. So there is no any writtings to DB.
	 * Updates that are made depend on current given status of the transaction and it's old status (received from DB).
	 * Populates $_SESSION['tps_transaction_updates'] with UpdatesVO data hash about ALL updated values of the nodes, users, products, etc.
	 * @param TransactionVO $trans
	 * @param Boolean $delete do we need to revert changes of this transaction (when deleting transaction)
	 * @return UpdatesVO delta of the changed values
	 */
	public static function _calculate_delta_updates(&$trans, $delete = FALSE) {
		$errMsg	= null; $upd = new UpdatesVO();													//prepeare error string and update object
		
		//prepeare status variables
		$status = $trans->status;																//get curr trans status
		if(isset($trans->data->status)) $oldStatus = $trans->data->status['old'];				//get the old status if there is one
		else $oldStatus = TPSTrans::S_NDEFERR;													//if not - then it's the first time transaction is added, so set NOT DEFINED statatus
		
		//prepeare if delete multiplier
		if($delete) $delMinus = -1; 															//if need to del this var will be -1 and all dependend values are multiplyed by that var, so on delete we get them at negative values
		else $delMinus = 1;																		//else (not delete) war is 1 so all multiplications on this var will end up with no numbers change
		
		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		
		//----
		//MONEY PROCESSING FOR >="PAYED" STATUS:
		if( ($status>=TPSTrans::S_PAYED && $oldStatus<TPSTrans::S_PAYED)  || 					//если сейчас статус больше или равен "оплачен" и прежний статус был меньше чем оплачен (то есть еще не платили ранее)
			($status==TPSTrans::S_DELETED && $oldStatus>=TPSTrans::S_PAYED)  ) {				//или если сейчас удаляем, а прошлый статус был "оплачен" или больше (то есть если в удаляемой транзакции были учтены деньги - надо их пересчитать)
			
			//DEBT/CREDIT PROCESSING:
			if($trans->type==TPSTrans::T_SELL && isset($trans->data->debt)) {
				//delta debt value of the user.
				$upd->users->{$trans->usr_they}->debt = round($trans->data->debt,2) *$delMinus;
			} else if($trans->type==TPSTrans::T_DEBTBACK) {
				//get curr debt of the user
				$upd->users->{$trans->usr_they}->debt =-round($trans->value, 2)*$delMinus;		//save updated debt value to send to flash
			}//debt/credit
		
		
			//BALANCE PROCESSING: add/remove value to the money balance to sellPlace cashbox where transaction was created
			//if we have some value to add/remove from sell place balance and transaction type is allowing to do this
			if($trans->value!=0 && ($trans->type==TPSTrans::T_SELL || $trans->type==TPSTrans::T_DEBTBACK || $trans->type==TPSTrans::T_INCOME || $trans->type==TPSTrans::T_RETURN)) {
				$upd->sellPlaces->{$trans->place}->money = round($trans->value, 2) *$delMinus;		//save balance value to send to flash
			}
			
			//USER WAGE(зарплата): add percent of the sold value, decrease same percent on RETURN transactions
			if($trans->type==TPSTrans::T_SELL || $trans->type==TPSTrans::T_RETURN) {
				$currPerc = TPSCore::getFieldValue('user', $trans->usr_us, 'percent', 0);
				$deltaWage= (($trans->value+@$trans->data->debt)*$delMinus) * ($currPerc*0.01);
				$deltaWage= round($deltaWage, 2);
				$upd->users->{$trans->usr_us}->money = $deltaWage;								//save curr wage amount value to send to flash
			}
		
		}//MONEY PROCESSING FOR PAYED STATUS //---
		
		//----
		//AVAILIABLE PROCESSING FOR >="PACKED" STATUS:
		if( ($status>=TPSTrans::S_PACKED && $oldStatus<TPSTrans::S_PACKED) ||					//если сейчас статус больше или равен "упакован" и прошлый статус еще не был "упакован" (менее чем "упакован") - значит тлько сейчас мы должны просчитать наличие (уменьшить его)
			($status==TPSTrans::S_DELETED && $oldStatus>=TPSTrans::S_PACKED)  ) {				//или если сейчас удаляем, а прошлый статус был больше или равен "упакован" (то есть когда наличие было уже учтено, поэтому при удалении транзакции, его надо снова пересчитать)	
		
			//TRANSFER trans - need have target sell place delta ID
			if($trans->type==TPSTrans::T_TRANSFER) {
				//get target place ID by loading sell place index from user_they data (in transfer type they user is seller of our target sell place)
				$targPlaceNID = TPSCore::getFieldValue('user' , $trans->usr_they, 'place', 0);
				$targPlaceID  = TPSCore::getFieldValue('place', $targPlaceNID, 'index', 0);
				if($targPlaceID==$trans->place) return "Error: попытка трасфера товара в то же место продажи с которого он берется.";
			}
			
			//INVONTORY trans - calculate difference from given avail value and value from a base
			if($trans->type == TPSTrans::T_INVENROTY && isset($trans->data->products)) {
				foreach ($trans->data->products as &$prod) {
					if( (!$delete && $prod->amount<0) ||
						( $delete &&(!isset($prod->availReal)|| !isset($prod->availDiff)  ))
					) {$errMsg = 'FATA: bad filled product data.'; continue;}
						
					if(!$delete) {
						$prod->availReal = $prod->amount;												//в инвентаризации amount хранит просчитанное финальное значение кол-ва продукта, а не его сдвиг, поэтому мы вычисляем разницу между данными из БД и присланными данными
						$availDB = TPSCore::getFieldValue('product', $prod->nid, 'avail', $trans->place);
						$prod->availDiff = $prod->availReal - $availDB;									//need to store this to be able to delete trans
						$prod->amount = $prod->availDiff;
					}
				}
			}
			
			//AVAILABLE AMOUNT PROCESSING: decrease avaliable amount of bought products
			if(isset($trans->data->products))														//if there is products info in data hash
				if($trans->type==TPSTrans::T_SELL || $trans->type==TPSTrans::T_TRANSFER || $trans->type==TPSTrans::T_INCOME || $trans->type==TPSTrans::T_REPACK || $trans->type==TPSTrans::T_RETURN || $trans->type==TPSTrans::T_INVENROTY)
				foreach ($trans->data->products as $prod) {
					if(is_array($prod)) return 'Ошибка представления данных! Продукты в массиве не приведены к типу object.';
				
					//get amount multiplayer, depending on trans type (decrease or increase availability)
					if($trans->type==TPSTrans::T_SELL || $trans->type==TPSTrans::T_TRANSFER) $amountOperation = -1;		//use negative multiplayer for this transactions types
					else $amountOperation = 1;//for income or return - using positive multiplayer
				
					//calculate delta avaliable amountS of product (for every place/delta)
					$deltaAvail= array();//$deltaAvail[$trans->place]=0;$deltaAvail[$targPlaceID]=0;//prepeare zero values for source and target sell places avail (надо, чтобы ниже можно было использовать + а не = и збежать ошибки когда делается трансфер из и в одно и то же место)
					$deltaAvail[''.$trans->place]= $prod->amount *$amountOperation *$delMinus;		//decrease/increase avaliable amount in curr sell palce ($amountOperation is setting negative or positive amount will be)
					if($trans->type==TPSTrans::T_TRANSFER)$deltaAvail[$targPlaceID]=abs($prod->amount)*$delMinus;//increase available in target sell place (only on transfer transactions; on transfer amounts are negative, so use another - operation, to have + (decrease) finally)
				
					//updates: store curr availability to sessions and renew 'changed' timestamp on sold product
					$deltaProd = (object)array('avail'=>$deltaAvail);
					$upd->products->{ ''.$prod->nid } = $deltaProd;							//save availability to UpdatesVO data object
				}//each prod
		
		}//AVAILIABLE PROCESSING PACKED //---
			
		//return data or error message
		if($errMsg) return $errMsg;
		else 		return $upd;
	}
	

}

?>
