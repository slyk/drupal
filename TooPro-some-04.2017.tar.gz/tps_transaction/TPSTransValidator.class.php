<?php

/**
 * Storing different validators for transactions.
 * Security check functions will pass data thru needed validators from here
 * depending on transaction type.
 * 
 * @author SlyK
 *
 */
class TPSTransValidator {

	
	/**
	 * validate transaction depend on it's type.
	 * Go thru products (their price) and sale used if needed.
	 * 
	 * @param TPSTrans $trans transaction to be validated. WARN! Some data may be changed in transaction (arrays to objects, default values, etc.)
	 * @param boolean $deepCheck
	 * 		If TRUE will check for products price, sales, cost, final value, debts, etc.
	 * 		This will take longer time and neede only for remote clients, because they can passs enything to transaction.
	 * 		For local drupal generated transactions there is no need to check all this stuff,
	 * 		because we create transaction in a safe place already.
	 * @param boolean $delete if need to delete given transactions - don't need to check many of params, because the trans is already
	 * 		loaded from DB, so everything is fine, but need to check access for users to delete it and inventory time.
	 * 
	 * @return boolean|string TRUE if given transaction can be saved and STRING with error text on some error.
	 */
	public static function validate(&$trans, $deepCheck = TRUE, $delete = FALSE) {
		
		//all types validation
		if(!$trans) return 'ERROR: No transaction is given.';		//is there any data given
		self::castHashes($trans);									//cast to transaction and data to objects
		if(!isset($trans->type)  || $trans->type==TPSTrans::T_NDEF)	return 'Не указан тип транзакции.';//check transaction type
		if(!$delete && ( isset($trans->id)|| $trans->id != NULL))	return 'При добавлении новой транзакции ID должно быть пустым.';
		if( $delete && (!isset($trans->id)|| $trans->id == NULL))	return 'При удалении транзакции - id должно быть указано.';
		if( $delete) return self::_validate_ANY_delete($trans, $deepCheck);//for DELETE, don't need to check other data - just validate user acces and exit
		if(!isset($trans->id) && isset($trans->data->status))		return 'Нельзя указывать историю статусов для новых транзакций.';
		if(isset($trans->data->status) && !isset($trans->data->status['old'])) return 'Не указан прежний статус транзакции. Системная ошибка.';
		
		// PLACE CHECK:   - - -
		if(!isset($trans->place)) 									return 'Не указано место продажи.';
		if($trans->place!=TPSCore::currPlaceDID() && !user_access('administer transactions') && !user_access('add transactions any place'))return 'Вам разрешено проводить транзакции только в текущем месте продажи.';
		if($deepCheck) if(!TPSCore::placeNID($trans->place))		return 'Указанного места продажи нет в системе (или оно неправильно настроено).'; 

		
		// USERS CHECK:   - - -
		if(!user_access('add transactions'))						return 'У вас нет прав на добавление транзакций.';
		if(!isset($trans->usr_us)||!isset($trans->usr_they))		return 'Ну указан покупатель или продавец.';
		
		//by default the creator of transactions - is logged in user (only admin can add transactions from other users)
		global $user;
		if(isset($trans->usr_us) && $trans->usr_us != $user->uid) {
			if(!user_access('administer transactions'))				return 'Нельзя добавлять транзакции от лица другого человека.';
		} else $trans->usr_us = $user->uid;
		
		//check existance of the users (security for remote clients, internal php call knows which users exists so will not try make transactions on non existing users)
		if($deepCheck) {
			$args= array(':uids'=>array_unique(array($trans->usr_us,$trans->usr_they)));//дубли могут быть при расфасове, когда и продавец и покупатель - один uid
			$cnt = db_query("SELECT COUNT(*) FROM {users} WHERE `uid` IN(:uids)",$args)->fetchField();
			if($cnt!=count($args[':uids']))							return 'Указанного клиента нет в базе.';
		}
		
		
		//TIMESTAMPS:    - - -   (for php they inited in constructor, but for remote clients need to set them manually)
		if(!isset($trans->created) || $trans->created==0) $trans->created=time();//may be given past time, to indicate yesterday transaction for example, but:
		$trans->changed = time();									//changed - can not be setted by hand, so you can see when actually yesterday transaction was added to the base (if there was no new changed to it after adding)

		
		// BY TYPE VALIDATION: (run private functions of the validator for each transactions type - there are separate function)
		$typeName = TPSTrans::getTypeName($trans->type);
		if(is_string($typeName)) return call_user_func(array(TPSTransValidator::i(),"_validate_".$typeName), $trans, $deepCheck);
		
	}//validate()
	
	
	/**
	 * Cast different assoc array hashes to stdClass objects (like the full transaction, or its data hash, or products in data).
	 * MUST CALL! this when trying to work with transactions, even if you know that the data was validated eralier,
	 * because, for example, sending thru RPC can cast objects to assoc arrays, so need to fix them.
	 * 
	 * @param array|object $trans
	 * @param $classCastOnly if TRUE - will cast data hash to TPSTrans calss only. Data casting is ommited.
	 * @return TPSTrans
	 */
	public static function castHashes(&$trans, $classCastOnly=FALSE) {
		//cast transaction data hash(from object or from array - do not important) to TPSTrans
		if(get_class($trans)!='TPSTrans') {
			$trans = new TPSTrans(0,0,$trans);
		}
		if($classCastOnly) return $trans;
		
		//cast data hash and products in it to objects
		if(is_array($trans->data)) $trans->data = (object)$trans->data;//convert data hash from array to object
		if(isset($trans->data->products)) foreach($trans->data->products as $key=>&$prod) {
			if(is_array($prod)) $trans->data->products[$key] = (object)$prod;
		}
		
		return $trans;
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	/**
	 * Validate all given data for SELL trnsaction type.
	 * @param TPSTrans $trans Can be modified by the needs of validator!! (conver arrays to objects, zero some values, etc.)
	 * @return string if some error found, or NULL/FALSE if all ok. Given $trans can be modified!!
	 */
	private function _validate_SELL(&$trans, $deepCheck) {
		if(!isset($trans->data))						return 'Корзина не заполнена (или не передана в скрипт).';
		if(isset($trans->data->debt) && $trans->data->debt<0)return 'Значание "долга" не может быть отрицательным.';
		if(isset($trans->data->debt) && $trans->data->debt>1)return 'Давать в долг нельзя.';
		if($trans->value<0)								return 'Изменение баланса не может быть отрицательным для данного типа транзакции.';//negative values can have only INCOME and RETURN transactions
		if(self::hadInventoryAfterTransCreated($trans))	return 'Один из товаров попал под переучет уже после указанной даты транзакции.';
		$ret = self::__validate_ANY_products_array($trans); if(is_string($ret)) return $ret;
		
		if($deepCheck) {
			//check products prices and final cost value (with discount)
			$ret = self::__validate_SELL_deep($trans); if(is_string($ret)) return $ret;
		}
	}
	
	/**
	 * Validate all given data for TRANSFER trnsaction type.
	 * @param TPSTrans $trans Can be modified by the needs of validator!! (conver arrays to objects, zero some values, etc.)
	 * @return string if some error found, or NULL/FALSE if all ok. Given $trans can be modified!!
	 */
	private function _validate_TRANSFER(&$trans, $deepCheck) {
		if(!user_access('add transfer transactions'))	return'У вас нет прав на добавление трансферных транзакций.';
		if(!isset($trans->data))						return 'Корзина не заполнена (или не передана в скрипт).';
		if(self::hadInventoryAfterTransCreated($trans))	return 'Один из товаров попал под переучет уже после указанной даты транзакции.';
		$trans->value = 0;								//reset values to 0, because drupal can't save NaN values
		$ret = self::__validate_ANY_products_array($trans); if(is_string($ret)) return $ret;
		if($deepCheck) {
			
		}
	}
	
	/**
	 * Validate all given data for INCOME trnsaction type.
	 * @param TPSTrans $trans Can be modified by the needs of validator!! (conver arrays to objects, zero some values, etc.)
	 * @return string if some error found, or NULL/FALSE if all ok. Given $trans can be modified!!
	 */
	private function _validate_INCOME(&$trans, $deepCheck) {
		if(!user_access('add income transactions'))		return 'У вас нет прав на добавление приходных транзакций.';
		if(!isset($trans->data))						return 'Корзина не заполнена (или не передана в скрипт).';
		if(self::hadInventoryAfterTransCreated($trans))	return 'Один из товаров попал под переучет уже после указанной даты транзакции.';
		if($trans->value>0) 							return 'При закупке баланс должен уменьшаться.';
		$ret = self::__validate_ANY_products_array($trans); if(is_string($ret)) return $ret;
		if($deepCheck) {
			
		}
	}
	
	/**
	 * Validate all given data for DEBTBACK trnsaction type.
	 * @param TPSTrans $trans Can be modified by the needs of validator!! (conver arrays to objects, zero some values, etc.)
	 * @return string if some error found, or NULL/FALSE if all ok. Given $trans can be modified!!
	 */
	private function _validate_DEBTBACK(&$trans, $deepCheck) {
		if(!isset($trans->value)) 						return 'Не указана сумма возвращаемого долга.';
		if($trans->value<0)								return 'Изменение баланса не может быть отрицательным для данного типа транзакции.';//negative values can have only INCOME and RETURN transactions
		if($trans->status != TPSTrans::S_FINISHED)		return 'Нельзя указывать статус для данного типа транзакции.';
	}
	
	/**
	 * Validate all given data for REPACK trnsaction type.
	 * @param TPSTrans $trans Can be modified by the needs of validator!! (conver arrays to objects, zero some values, etc.)
	 * @return string if some error found, or NULL/FALSE if all ok. Given $trans can be modified!!
	 */
	private function _validate_REPACK(&$trans, $deepCheck) {
		if(!user_access('add repack transactions')) 	return 'У вас нет прав на добавление расфасовок.';
		//if($trans->status != TPSTrans::S_FINISHED)		return 'Нельзя указывать статус для данного типа транзакции.';
		if(TPSTransValidator::hadInventoryAfterTransCreated($trans))return 'Один из товаров попал под переучет уже после указанной даты транзакции.';
		$trans->value = 0;								//reset values to 0, because drupal can't save NaN values
		$ret = self::__validate_ANY_products_array($trans); if(is_string($ret)) return $ret;
		if($deepCheck) {
			
		}
	}
	
	/**
	 * Validate all given data for RETURN trnsaction type.
	 * @param TPSTrans $trans Can be modified by the needs of validator!! (conver arrays to objects, zero some values, etc.)
	 * @return string if some error found, or NULL/FALSE if all ok. Given $trans can be modified!!
	 */
	private function _validate_RETURN(&$trans, $deepCheck) {
		if(!user_access('add return transactions'))		return 'У вас нет прав оформлять возврат товара.';
		if(!isset($trans->data))						return 'Корзина не заполнена (или не передана в скрипт).';
		if($trans->status != TPSTrans::S_FINISHED)		return 'Нельзя указывать статус для данного типа транзакции.';
		if(!isset($trans->value) || $trans->value>0)	return 'При возврате сумма возвращаемых средств должны быть положительна.';
		if(self::hadInventoryAfterTransCreated($trans))	return 'Один из товаров попал под переучет уже после указанной даты транзакции.';
		$ret = self::__validate_ANY_products_array($trans); if(is_string($ret)) return $ret;
		if($deepCheck) {
			//TODO: find past transaction where returned product was sold to the buyer.
		}
	}
	
	/**
	 * Validate all given data for INVENTORY trnsaction type.
	 * @param TPSTrans $trans Can be modified by the needs of validator!! (conver arrays to objects, zero some values, etc.)
	 * @return string if some error found, or NULL/FALSE if all ok. Given $trans can be modified!!
	 */
	private function _validate_INVENTORY(&$trans, $deepCheck) {
		if(!user_access('add inventory transactions')) 	return 'У вас нет прав проводить инвентаризацию.';
		if($trans->status != TPSTrans::S_FINISHED)		return 'Нельзя указывать статус для данного типа транзакции.';
		if($trans->place!=TPSCore::currPlaceDID())		return 'Инвентаризировать можно только текущее место продажи.';
		//if($trans->created < (time()-3))				return 'Нельзя проводить переучет на прошедшее время.';
		$trans->value = 0;								//reset values to 0, because drupal can't save NaN values
		$ret = self::__validate_ANY_products_array($trans); if(is_string($ret)) return $ret;
	}
	
	/**
	 * Validate all given data for TRASH trnsaction type.
	 * @param TPSTrans $trans Can be modified by the needs of validator!! (conver arrays to objects, zero some values, etc.)
	 * @return string if some error found, or NULL/FALSE if all ok. Given $trans can be modified!!
	 */
	private function _validate_TRASH(&$trans, $deepCheck) {
		$trans->value = 0;								//reset values to 0, because drupal can't save NaN values
		if($trans->status != TPSTrans::S_FINISHED)		return 'Нельзя указывать статус для данного типа транзакции.';
		$ret = self::__validate_ANY_products_array($trans); if(is_string($ret)) return $ret;
		return 'Этот тип транзакций еще в разработке. Его нельзя использовать.';
	}
	
	
	/**
	 * Validate given transaction to be deleted: user access check and inventory time.
	 * @param TPSTrans $trans
	 * @param boolean $deepCheck
	 * @return string if some error found, or NULL/FALSE if all ok.
	 */
	private function _validate_ANY_delete(&$trans, $deepCheck) {
		//check if its already deleted
		if($trans->status==TPSTrans::S_DELETED) 		return 'Попытка повторного удаления! Транзакция уже была удалена.';
		
		//user rights to delete transaction (own and others)
		global $user;
		if($trans->usr_us != $user->uid)
		{if(!user_access('administer transactions'))	return 'У вас нет прав удалять чужие транзакции.';}
		else{if(!user_access('administer own transactions'))return 'У вас нет прав удалять транзакции.'		 ;}
		
		//check inventory time
		if(isset($trans->data->products) && is_array($trans->data->products) &&
		   TPSTransValidator::hadInventoryAfterTransCreated($trans))return 'Один из товаров попал под переучет уже после указанной даты транзакции.';
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Check does some of the products from the list had beed inventoried after the given transaction time.
	 * Because transactions can be added to past time (ex. today add transactions about yesterday sellings),
	 * and if today product has been inventoried already - its avail changed today to real avail value,
	 * so don't need to add yesterday sell transaction - because it may change prod avail to the wrong number.
	 * 
	 * Если переучет был сегодня, уже посчиталась недостача, была сохранена, а реальное кол-во товара внесено в базу
	 * и теперь по базе есть реальное кол-во на сегодняшиний день. Значит добавлять вчерашние продажи уже нельзя,
	 * так как это повлияет на текущее реальное кол-во товара.
	 * 
	 * @param TPSTrans $trans
	 * 
	 * @return boolean TRUE if there were inventarisations of some product from given transaction, so can't add transaction to the DB.
	 */
	private function hadInventoryAfterTransCreated(&$trans) {
		//get all inventory trans from given place that was made after given transaction created time
		$filter = new TransactionsRangeFilterVO();
		$filter->type = array(TPSTrans::T_INVENROTY);
		$filter->dateFrom = $trans->created;
		$filter->place = array($trans->place);
		$filter->limit = 200;
		$filter->fields= array('id','data','status');
		$inv = TPSTransAPI::range( $filter );
		if(count($inv)==0) return FALSE;
		
		//make a list of products that we are trying to change avail for
		$prodIds = array();
		if(!is_array($trans->data->products)) return FALSE;
		foreach($trans->data->products as &$prod) $prodIds[] = $prod->nid;

		//serach in inventory transactions products that match ids from given transaction
		foreach($inv as &$invTrans) {
			if($invTrans->id == $trans->id) continue;					//pass the same invent trans that we a trying to delete
			if($invTrans->status == TPSTrans::S_DELETED) continue;		//deleted transactions - may pass.
			foreach($invTrans->data->products as &$invProd)
				if(in_array($invProd->nid, $prodIds)) {
					return TRUE;
			}
		}
		
		return FALSE;
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	/**
	 * RE-CHECK COST VALUES in given transaction (debt+value payed and all prices in products).
	 * Values from given data must be equal to appropriate values of the products loaded from db
	 * (app calculations = server calculations) (чтобы нельзя было отправить неправильные данные с клиента)
	 * @param $trans object filled with data about transaction. must have 'value','data' parameters set
	 * @return String error description if there was some error... or just nothing
	 */
	private function __validate_SELL_deep(&$trans) {
		$fullPrice = 0;
		$place = $trans->place;
		
		//check transaction without discounts
		foreach($trans->data->products as &$prod){
			$prodPrice = TPSCore::getFieldValue('product', $prod->nid, 'price', $place);
			if(!$prodPrice) $prodPrice = TPSCore::getFieldValue('product', $prod->nid, 'price', 0);
			$fullPrice+= abs($prodPrice*$prod->amount);//in sell trans the amounts are negative, as a result - fullPrice will be negative, but we need it as positive value!
			
			//проверки цен
			if(isset($prod->price[$place]) && $prod->price[$place]!=$prodPrice )	return "Несовпадение цен на товар (ID ".$prod->nid.") ... обновите данные в программе. (".$prod->price[$place]." и $prodPrice)";//проверка цены в месте продажи
			if(isset($prod->priceCurr)) {
				if($prod->priceCurr != $prodPrice ) return "Несовпадение цен на товар (ID {$prod->nid})... обновите данные в программе. ({$prod->priceCurr} и $prodPrice)";//проверка текущей используемой цены
			} else $prod->priceCurr  = $prodPrice;
		}
		
		// Если долг не указан в data, то он просчитается при просчете дискаунта
		$costToPay = self::_discout_calculation($trans, $fullPrice);
		if(!is_numeric($costToPay)) return $costToPay;
		
		//проверка полной цены и задолженности
		if(isset($trans->data->debt)) {
			if(!TPSCore::floatsEqual($costToPay, ($trans->value+$trans->data->debt) )) {return "Расчитанная цена покупки($costToPay) не совпадает с указанной(".(($trans->value+@$trans->data->debt))."[[{$trans->value}+{$trans->data->debt}]]";}
		} else {
			$trans->data->debt = $costToPay - $trans->value;			//если долг не указан, но заплаченных денег не хватает - просчитать долг (обычно флэш клиент указывает долг, поэтому это пригодится только для php клиента)
			if($trans->data->debt>1) return "В долг давать нельзя.";		
		}
		if($trans->data->debt<0) $trans->data->debt=0;					//чел может заплатить без учета скидки, долг будет отрицательным, обнулим, чтобы не быть должными покупателю	
	}
	
	/**
	 * Call this BEFORE any deep validation of product and updates calculation:
	 * checks for existing of needed props of the products in prod array, convert them to object from array (if needed).
	 * @param TPSTrans $trans
	 * @return string
	 */
	private function __validate_ANY_products_array(&$trans) {
		if(!$trans->data->products || !is_array($trans->data->products))return 'Не указан список товаров';
		foreach ($trans->data->products as &$prod) {
			if(is_array($prod)) $prod = (object)$prod;					//if prod given as array - convert to object
			if(!$prod->nid || !isset($prod->amount))					return 'Не указаны обзательные данные одного из продуктов транзакции.';
			if(($trans->type!=TPSTrans::T_REPACK && $trans->type!=TPSTrans::T_INVENROTY) && $prod->amount<0) return 'Нельзя передавать негативное кол-во товара в транзакции.';
			if($trans->type==TPSTrans::T_INVENROTY && $trans->status!=TPSTrans::S_DELETED&& $prod->amount<0) return 'Нельзя передавать негативное кол-во товара в транзакции.';//для инвентарзиации все же amount может быть отрицательным, после процессина транзакции в calculate_updates, но если транзакция новая, то amount - это посчитанное кол-во, значит только положительное 
		}
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Get instance of this class
	 */
	static function i(){
		if (self::$instance == NULL){self::$instance = new TPSTransValidator();}
		return self::$instance;
	}
	static private $instance = NULL;
	
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	///////////////////////////////////////////////// DISCOUNT /////////////////////////////////////////////////////////////
	//TODO: move discounts to separate module
	/**
	 * Returns $costToPay calculated using $transaction->data->saleUsed discount rules. If there is some error it will ret STRING.
	 * It's analog of OrderProxy.refreshCart() in Flex.
	 * @param Object $transaction - fully filled object WITH data->saleUsed param that have 'nid' and 'usedDataId' properties
	 * @param Number $fullCost - server calculated full cost of products without discount
	 * @return Number final cost of all transaction products (full order) with applyed sale/discount, OR!!! error string.
	 */
	private function _discout_calculation(&$transaction, $fullCost) {
		if(!isset($transaction->data->saleUsed)) return $fullCost;				//if there is no sale used - return fullCost - because there is no discount
		if(($transaction->value+@$transaction->data->debt)==$fullCost)return $fullCost;//if all transaction money equal fullCost - do not need to calculate discount - user already payed fullCost for products(payed meens real money and his debt)
		$costToPay = $fullCost;												//by default - costToPay discounted = full cost to pay
	
		//GET USED SALE DATA:
		//get info about sale (id and ised dataId(for sales that have more than one data fields))
		$saleNid	  = $transaction->data->saleUsed->nid;
		$usedDataDelta= $transaction->data->saleUsed->usedDataDelta; if(!$usedDataDelta) $usedDataDelta=0;
		$data = db_select("field_data_data", "d")
		->condition("entity_id",$saleNid)
		->condition("delta", $usedDataDelta)
		->fields("d",array("data_value"))
		->execute()
		->fetchField();
		$data = json_decode($data);
		if(!$data) return "Не получается загрузить данные об акции/скидке($saleNid:$usedDataDelta).";
	
	
		//CHECK SALE CONDITION:
		if(isset($data->condition)) {
			if(isset($data->condition->transaction)) {
				//value
				$tv = $data->condition->transaction->value;
				if(substr($tv,0,1)=='>' && !$fullCost>floatval(substr($tv,1))) return "Указанная акция/скидка не подходит (сумма покупки).";
	
				//debt (считаем что долга нет, потом проверим условие долга)
				//if(isset($transaction->data->debt) && $transaction->data->debt > $data->condition->transaction->debt) return "Указанная акция/скидка не подходит (долг).";
			}
		}
	
		//APPLY DISCOUNT:
		$dsk = $data->discount;
	
		//if discount is applyed to only some products - calculate costToPay discounting only needed products
		if(isset($dsk->products)) {
			$costToPay = 0;
			if(isset($dsk->products->ids)) {
	
				//select products from data (old and new versions)
				foreach($transaction->data->products as $prod) {
	
					//apply discount to current product price only (if needed)
					$prodPrice = $prod->priceCurr; 								//price is security checked earlier, so it's ok to use it right from $transaction object
					if(isset($dsk->products->ids->{$prod->nid})) {				//if curr product have discount (it's nid are in list of sale products-ids list)
						if($dsk->type=='percent')
							$prodPrice = $prodPrice - $prodPrice *$dsk->products->ids->{$prod->nid}*0.01;
					}
					//add final product price to all costToPay value
					$costToPay += $prodPrice*$prod->amount;
	
				}//foreach
			}
	
			//else discount is applyed to fullcost of the transaction
		} else {
			if($dsk->type=='percent')
				$costToPay = $fullCost - $fullCost *$dsk->value*0.01;		//apply discount percent ot full purchase cost
			//return ' '.$transaction->value.' '.$fullCost.' '.$costToPay.print_r($dsk,1);
		}
	
		//CHECK SALE DEBT CONDITION:
		//вначале считается, что долга нет, просчитывается скидка, получаем цену со скидкой
		//потом просчитываем сумму долга от скидочной цены. если он есть, то проверям долговое условие скидки
		if(!isset($transaction->data->debt)) $transaction->data->debt = $costToPay - $transaction->value;//calculate debt from cotsToPay price
		if(isset($data->condition) && isset($data->condition->transaction)) {
			if($fullCost != $costToPay)
				if($transaction->data->debt > $data->condition->transaction->debt) return "Указанная акция/скидка не подходит (долг).".$transaction->data->debt;
		}
	
		return round($costToPay*100)/100;//floor
		//return $fullCost.' : '.$costToPay.' : '.print_r($dsk,1);
	}
	
}//class

?>
