<?php

/** 
 * The actual transaction class representing one transaction with its full info/data. 
 * 
 * @author SlyK
 * 
 */
class TPSTrans {
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	//Transaction types:
	
	/**not defined - there is some problems if you see this transaction type in db*/
	const  T_NDEF		= 0;
	
	/**standart selling. when debt+value>0*/
	const  T_SELL		= 1;
	
	/**move products from one place to another. traget sell place is the sell place that is selected for usr_they users of the transaction*/
	const  T_TRANSFER	= 2;
	
	/**income(закупка) of the products. when value<0*/
	const  T_INCOME		= 3;
	
	/**when user return back it's debt. when debt<0*/
	const  T_DEBTBACK	= 4;
	
	/**one product repacked/converted to receive another*/
	const  T_REPACK		= 5;
	
	/**buyer has returned product, and money was payed back (balance decreased)*/
	const  T_RETURN		= 6;
	
	/**product going to trash without any money for it :( */
	const  T_TRASH		= 7;
	
	/**inventarisation has been done and new values of the products replacing old values*/
	const  T_INVENROTY	= 8;
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	//Transaction statuses:
	
	/**products was sold, money received, sellers wage is payed and sell place balance changed */
	const  S_FINISHED	=100;
	
	/**can't be such transaction statuses, someting is wrong*/
	const  S_NDEFERR	=-1;
	
	/**transaction was deleted, all it's chages were reverted, it's needed only for information archive */
	const  S_DELETED	=-5;
	
	//SELL & TRANSFER & INCOME TYPES:
	
	/**user wants to buy something, but he is still thinking and changes of product list are allowed*/
	const  S_PREORDER	= 5;
	
	/**user has maked order, filled and accepted the list of products, check was sent to buyer and we are waiting for his payment*/
	const  S_ORDERED	= 10;
	
	/**we've received money for this transaction, but NOT SENDed PRODUCTS */
	const  S_PAYED		= 20;	//деньги добавляются в кассу или в долг покупателю (в зависимости от типа оплаты)
	
	/**all products in transaction is filled and packed for sending */
	const  S_PACKED		= 30;	//минусуется наличие товара
	
	/**products in transaction were sent, but buyer did NOT RECEIVED it yet */
	const  S_SENT		= 50;
	
	/**when transport company has delivered the product to the destination point, and we are waiting for buyer to grab it*/
	const S_DELIVERED	= 60;
	
	/**when order was sent and delivered, but we are still waiting for money from user (they are recorded to 'debt' on PAYED state и если мы ждем обратную доставку денег именно по этому заказу, то надо указывать этот статус, чтобы не забыть забрать деньги и учесть, что покупатель их определенно отправил */
	const S_WAINTDEBT	= 70;
	
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	//Other constants
	
	/**symbols used in int to symbolic id conversion */
	const  TID_CONV_SYBM = '0123456789QWERTYUPASDFGHJKLZXCVBNM-+';
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public $id;
	public $usr_they;
	public $usr_us;
	public $type;
	public $value;
	public $status;
	public $place;
	public $created;
	public $changed;
	public $data;
	public $note;
	
	
	/**
	 * Creates the new transaction.
	 * @param uint $type type of the transaction, must be given for all transactions, so it's required
	 * @param uint $place Delta place index (DID) whre the transactions is happends.
	 * @param array $dataReplace accos array of transactions data with the same names as properties of the transaction class. Will be copied to neede properties, replacing existing and already set data.
	 */
	public function __construct($type = self::T_NDEF, $place = -1, $dataReplace=null) {
		$this->type	   = $type;
		$this->created = time();
		$this->changed = time();
		$this->data	   = (object)array();
		$this->status  = TPSTrans::S_FINISHED;
		
		if($place<0) {
			$this->place = TPSCore::currPlaceDID();
		}
		
		//fill up class with the values from $dataReplace
		if($dataReplace) {
			if(is_object($dataReplace)) $dataReplace = (array)$dataReplace;		//conv to array
			$props = get_class_vars(__CLASS__); $props=array_keys($props);		//get all class variables					
			foreach ($props as $propName) if(isset($dataReplace[$propName])) {	//if data have val for prop
				$this->{$propName} = $dataReplace[$propName];					//save value to class obj
			}
		}
	}
	
	
	/**
	 * Writes transaction to DB transactions table.
	 * WARNING! This function will NOT calculate any updates and will not make validation.
	 * Use in ONLY if you know that transaction is in needed format and can be stored in DB.
	 * 
	 * Генерирует следующий/очередной id для транзакции, осеновываясь на правилах (см. gen_id()),
	 * пытается записать. При ошибки дублирования id - подбирает новый id - уже уникальный с проверкой БД.
	 * Сноа пытается записать - если все еще вываливается ошибка - сообщает о ней.
	 * 
	 * @param $writeMode string indicated one of the write modes (new_next, new_uniqe or update).
	 * 			See full description about write modes in appropriate constants.
	 * @param $uniqueOnDuplicate use TRUE when you do not need to give the transaction next id of the current day
	 * 		and on duplaceta you want to create uniue id that will not change lastID
	 * 		(используется при синхронизации, подробнее написано к параметру $unique в функции _gen_id())
	 * @param $update if isset, then update will be performed, not creating of the new trans
	 * @return string|null returns error message string or null - if there was no error on saving. 
	 */
	public function write_db_record_only($writeMode = WRITE_NEW_NEXT) {
		//unique flag
		if($writeMode==self::WRITE_NEW_UNIQUE) $unique = TRUE;
		else $unique = FALSE;
		
		//transaction ID work (convert to int or generate new)
		if($this->id) {
			$this->id = TPSTransAPI::IDstrTOint($this->id);						//convert symbolic id of the transaction to integer id
		} else {
			if($writeMode==self::WRITE_UPDATE) return 'No ID given';
			else $this->id = $this->_gen_id(false, $unique);					//generate transaction id
		}
		
		//primary keys for update
		if($writeMode==self::WRITE_UPDATE) $primKey = array('id');
		else $primKey = array();
		
		//writting to DB
		try{
			$ret = drupal_write_record('tps_transaction', $this, $primKey);}	//save transaction record to transaction table in db
		catch(Exception $e) {													//if some problem with writting to DB:
			if($e->getCode()==23000) {											//..for duplicates error:
				$this->id = $this->_gen_id($this, true, $unique);				//....generate another transaction id with checking for duplicates
				try{$ret = drupal_write_record('tps_transaction',$this);		//....and try save transaction now with rechecked id that don't have duplicates
				}catch(Exception $e){return "FATAL: db error on writting transaction!!!";}
			}
			else return "FATAL: db error on writting transaction!!!";			//.print_r($e,1);//if it's NOT duplicate entry error - exit with fatal error.
		}
		
		//finalize
		if($ret===FALSE) return "Can't add transaction to DB.";					//if can't be saved - tell that to error msg
		if(!$unique)variable_set('tps_transaction_lastid',$this->id);			//save last transaction id
		return null;
	}
	/**
	 * Write mode that gives the new transaction next ID prefix from the today transactions. On conflicts it will increase this prefix until there will be no conflicts.
	 */
	const WRITE_NEW_NEXT	= 'nnext';
	/**
	 * Write mode that gives the transaction unique ID if current ID is already taken(duplicate). (используется при синхронизации, подробнее написано к параметру $unique в функции _gen_id())
	 */
	const WRITE_NEW_UNIQUE	= 'nuniqe';
	/**
	 * Write mode that updsates existing transaction. ID param MUST be setted and must be in symbolic state.
	 */
	const WRITE_UPDATE		= 'update';
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public static function getTypeName($type) {
		switch($type) {
			case TPSTrans::T_SELL		: return 'SELL';	break;
			case TPSTrans::T_TRANSFER	: return 'TRANSFER';break;
			case TPSTrans::T_INCOME		: return 'INCOME';	break;
			case TPSTrans::T_DEBTBACK	: return 'DEBTBACK';break;
			case TPSTrans::T_REPACK		: return 'REPACK';	break;
			case TPSTrans::T_RETURN		: return 'RETURN';	break;
			case TPSTrans::T_TRASH		: return 'TRASH';	break;
			case TPSTrans::T_INVENROTY	: return 'INVENTORY';break;
			default: return FALSE;
		}
	}
	
	
	/**
	 * Set number of transaction as: 123(number of transaction today) + 1(sell place) + 1(year last digit) + 02(month) + 25(day fo month)
	 * THis meens maximum 10 sell places allowed now
	 *  1021251
	 *  2021251
	 *  . . . .
	 * 11021251
	 *
	 * @param $dbCheck set to TRUE, to check found id in db, to prevent duplicate entry errors.
	 * 		(нужен когда сбивается параметр 'tps_transaction_lastid', или после синхронизации,
	 * 		 или когда с одного компа постатся транзакции на разные места продаж(это может администрация) )
	 * 
	 * @param $unique set to TRUE to set some unique number (generated using past time big last id).
	 * 		Used when two synced databases have same transaction ids. Если сохранить конфликтную транзакцию под следующим lastID,
	 * 		то выйдет, что и все последующие сегодняшние транзакции с клиента пришлось бы передвигать по id, и выйдет путаница.
	 * 		При этом параметре транзакция по коду записывается на прошлый год и ставится нереально большой префикс (>88).
	 * 		Сгенерированный id проверяется и увеличивается, если находится конфликт.
	 * 		Старый id при этом записывается в note к транзакции.
	 *
	 */
	private function _gen_id($dbCheck = FALSE, $unique = FALSE) {
		$year = substr(date('y'),1);												//get year digit
		if($unique) { $year = intval($year) - 1; $dbCheck = TRUE; }					//for unique - minus 1 year
		
		//sufix = sell place index    + year last digit + month      + day
		$suffix = $this->place  .  $year     .    date('m') . date('d');		//generate suffix for transaction id
		
		//count number of todays transactions to know next number
		$last = variable_get('tps_transaction_lastid', "0$suffix");					//get current last inserted transaction id
		if(substr($last,-strlen($suffix))==$suffix) {								//if last trans id suffix = curr generated suffix (today transaction)
			$lastId = intval(  str_replace($suffix,'',$last)  );					//..get last trans id string
			$lastId++;																//..increase id
		} else {
			$lastId = 1;															//else it's another suffix, so start again with 1
		}
		if($unique) $lastId = 88;													//if uniqe asked - just set big last id
		
		//db check and increase if needed
		$interval = 10;																//prepeare search interval
		while($dbCheck) {															//while $dbCheck is true - keep searching
			$lastPlusInt = ($lastId+$interval); $lastPlusInt.= $suffix;				//generate id of the transaction with added interval. Ex.: first id - 1223344, interv - 11223344
			$cnt = db_query("SELECT COUNT(*) FROM {tps_transaction} WHERE `id`=$lastId$suffix OR `id`=$lastPlusInt")->fetchField();//ask for transactions with id. Ex: for 1223344 and 11223344, and get count of found rows
			switch($cnt) {															//depend on found rows count we can undestan in what interval to search for free id
				case 2: $lastId += $interval+1; break;								//if all 2 rows found - our free id is somewhere further that id with interval (11223344), so our lastId is increased by (insterval+1) ex.:12223344, and we are moving on nex step of the cycle
				case 1: $lastId++; $interval=round($interval/2.0); break;			//if only one row found - free id is somwher in interval betwen 1223344 and 11223344, so decrease interval size, and serach in smaller interval in the next cycle steps
				case 0: $dbCheck = false; break;									//if 0 rows found - we have our free id in $lastId var, so unset $dbCheck flag to stop cycle
			}
		}//while dbCheck
		
		//final returns
		$id = $lastId . $suffix;													//finally add suffix to id
		return $id;																	//and return
	}
	
	
	
}

?>